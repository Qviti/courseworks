import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:vpn_basic_project/models/vpn_config.dart';
import 'package:vpn_basic_project/models/vpn_status.dart';

class VpnEngine {
  // Define channel names for communicating with the platform-specific code.
  static final String eventChannelVpnStage = "vpnStage";
  static final String eventChannelVpnStatus = "vpnStatus";
  static final String methodChannelVpnControl = "vpnControl";

  // Stream to listen for VPN connection stages from the native platform.
  static Stream<String> snapshotVpnStage() => EventChannel(eventChannelVpnStage)
      .receiveBroadcastStream()
      .cast<String>();

  // Stream to listen for VPN connection status updates, converting JSON to VpnStatus objects.
  static Stream<VpnStatus?> snapshotVpnStatus() => EventChannel(eventChannelVpnStatus)
      .receiveBroadcastStream()
      .map((eventStatus) => VpnStatus.fromJson(jsonDecode(eventStatus)))
      .cast<VpnStatus?>();

  // Initiates VPN connection using provided configuration.
  static Future<void> startVpnNow(VpnConfiguration vpnConfiguration) {
    return MethodChannel(methodChannelVpnControl).invokeMethod(
      "start",
      {
        "config": vpnConfiguration.config, // VPN configuration details.
        "country": vpnConfiguration.countryName, // Selected country for the VPN connection.
        "username": vpnConfiguration.username, // Username for authentication.
        "password": vpnConfiguration.password, // Password for authentication.
      },
    );
  }

  // Stops the VPN connection.
  static Future<void> stopVpnNow() {
    return MethodChannel(methodChannelVpnControl).invokeMethod("stop");
  }

  // Activates the VPN kill switch, blocking internet access if the VPN disconnects.
  static Future<void> killSwitchOpenNow() {
    return MethodChannel(methodChannelVpnControl).invokeMethod("kill_switch");
  }

  // Requests a refresh of the current VPN connection stage.
  static Future<void> refreshStageNow() {
    return MethodChannel(methodChannelVpnControl).invokeMethod("refresh");
  }

  // Retrieves the current stage of the VPN connection.
  static Future<String?> getStageNow() {
    return MethodChannel(methodChannelVpnControl).invokeMethod("stage");
  }

  // Checks if the VPN is currently connected.
  static Future<bool> isConnectedNow() {
    return getStageNow().then((valueStage) => valueStage!.toLowerCase() == "connected");
  }

  // Constants representing various stages of VPN connection.
  static const String vpnConnectedNow = "connected";
  static const String vpnDisconnectedNow = "disconnected";
  static const String vpnWaitConnectionNow = "wait_connection";
  static const String vpnAuthenticatingNow = "authenticating";
  static const String vpnReconnectNow = "reconnect";
  static const String vpnNoConnectionNow = "no_connection";
  static const String vpnConnectingNow = "connecting";
  static const String vpnPrepareNow = "prepare";
  static const String vpnDeniedNow = "denied";
}
