import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vpn_basic_project/models/vpn_config.dart';
import 'package:vpn_basic_project/models/vpn_info.dart';
import 'package:vpn_basic_project/appPreferences/appPreferences.dart';
import 'package:vpn_basic_project/vpnEngine/vpn_engine.dart';

// Create a class ControllerHome and extends it with GetxController for state management
class ControllerHome extends GetxController
{
  // Initialize the vpn info by getting it from app preferences
  final Rx<VpnInfo> vpnInfo = AppPreferences.vpnInfoObj.obs;
  // Setting the initial vpn connection state to disconnected
  final vpnConnectionState = VpnEngine.vpnDisconnectedNow.obs;

  // Function to connect to vpn
  void connectToVpnNow() async
  {
    // Check if the configuration data is empty, if yes then show a snack bar asking to select country
    if(vpnInfo.value.base64OpenVPNConfigurationData.isEmpty)
    {
      Get.snackbar("Country / Location", "Please select country / location first.");

      return;
    }

    // Check if the connection state is disconnected
    if(vpnConnectionState.value == VpnEngine.vpnDisconnectedNow)
    {
      // Convert the base64 configuration data to a string
      final dataConfigVpn = Base64Decoder().convert(vpnInfo.value.base64OpenVPNConfigurationData);
      final configuration = Utf8Decoder().convert(dataConfigVpn);

      // Create a vpn configuration
      final vpnConfiguration = VpnConfiguration(
          username: "vpn",
          password: "vpn",
          countryName: vpnInfo.value.countryLongName,
          config: configuration
      );

      // Try connecting to the vpn using the configuration
      await VpnEngine.startVpnNow(vpnConfiguration);
    }
    else
    {
      // If the connection state is connected or connecting, disconnect it
      await VpnEngine.stopVpnNow();
    }
  }

  // Getter for the color of the round vpn button, returns different color based on the connection state
  Color get getRoundVpnButtonColor
  {
    switch (vpnConnectionState.value)
    {
      case VpnEngine.vpnDisconnectedNow:
        return Colors.green;

      case VpnEngine.vpnConnectedNow:
        return Colors.redAccent;

      default:
        return Colors.orangeAccent;
    }
  }

  // Getter for the text of the round vpn button, returns different text based on the connection state
  String get getRoundVpnButtonText
  {
    switch (vpnConnectionState.value)
    {
      case VpnEngine.vpnDisconnectedNow:
        return "Connect";

      case VpnEngine.vpnConnectedNow:
        return "Disconnect";

      default:
        return "Connecting...";
    }
  }
}