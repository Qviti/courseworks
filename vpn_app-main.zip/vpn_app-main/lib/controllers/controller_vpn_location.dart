import 'package:get/get.dart';
import 'package:vpn_basic_project/models/vpn_info.dart';
import 'package:vpn_basic_project/apiVpnGate/api_vpn_gate.dart';
import 'package:vpn_basic_project/appPreferences/appPreferences.dart';

// Create a class ControllerVPNLocation and extend it with GetxController for state management
class ControllerVPNLocation extends GetxController
{
  // Retrieve the vpn server list from app preferences
  List<VpnInfo> vpnFreeServersAvailableList = AppPreferences.vpnList;

  // Create an observable for loading status of new locations, initially set to false
  final RxBool isLoadingNewLocations = false.obs;

  // Function to retrieve VPN information from the API
  Future<void> retrieveVpnInformation() async
  {
    // Set the loading status to true as the fetching process begins
    isLoadingNewLocations.value = true;

    // Clear the existing vpn server list
    vpnFreeServersAvailableList.clear();

    // Call the API to retrieve all available free VPN servers and set the result to the list
    vpnFreeServersAvailableList = await ApiVpnGate.fetchVpnServers();

    // Once the fetching process completes, set the loading status to false
    isLoadingNewLocations.value = false;
  }
}