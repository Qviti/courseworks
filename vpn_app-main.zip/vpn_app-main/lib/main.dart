import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vpn_basic_project/allScreens/home_screen.dart'; // Adjust the import path as necessary
import 'package:vpn_basic_project/appPreferences/appPreferences.dart';
import 'package:vpn_basic_project/appPreferences/appPreferences.dart';

late Size sizeScreen;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Hive and load preferences
  await AppPreferences.initHive();

  // Use Get.put to make ThemeController available for your app
  final ThemeController themeController = Get.put(ThemeController());

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Use Obx here to listen to changes in theme mode
    return Obx(() {
      return GetMaterialApp(
        title: 'LUPIN VPN',
        theme: ThemeData(
          // Define light theme settings
          brightness: Brightness.light,
          primarySwatch: Colors.blue,
          appBarTheme: AppBarTheme(
            color: Colors.white, // Light theme AppBar color
            centerTitle: true,
            elevation: 3,
          ),
          // Other light theme settings...
        ),
        darkTheme: ThemeData(
          // Define dark theme settings
          brightness: Brightness.dark,
          primarySwatch: Colors.blue,
          appBarTheme: AppBarTheme(
            color: Colors.blueGrey[900], // Dark theme AppBar color
            centerTitle: true,
            elevation: 3,
          ),
          bottomNavigationBarTheme: BottomNavigationBarThemeData(
            backgroundColor: Colors.blueGrey[900],
            selectedItemColor: Colors.white,
            unselectedItemColor: Colors.deepPurple.withOpacity(0.6),
          ),
          // Other dark theme settings...
        ),
        themeMode: Get.find<ThemeController>().isDarkMode.value ? ThemeMode.dark : ThemeMode.light, // Dynamically set theme mode
        debugShowCheckedModeBanner: false,
        home: HomeScreen(),
      );
    });
  }
}

class ThemeController extends GetxController {
  var isDarkMode = false.obs;

  @override
  void onInit() {
    super.onInit();
    _loadThemeMode();
  }

  Future<void> _loadThemeMode() async {
    isDarkMode.value = AppPreferences.isModeDark;
  }

  void toggleThemeMode() async {
    isDarkMode.value = !isDarkMode.value;
    AppPreferences.isModeDark = isDarkMode.value;
  }
}
