import 'package:flutter_test/flutter_test.dart';
import 'package:vpn_basic_project/models/vpn_status.dart';

void main() {
  group('VpnStatus Serialization Tests', () {
    test('toJson correctly serializes data including the connected property', () {
      final vpnStatus = VpnStatus(
        byteIn: '1000',
        byteOut: '2000',
        durationTime: '1h',
        lastPacketReceive: '10m',
      );

      final json = vpnStatus.toJson();

      expect(json['byte_in'], equals('1000'));
      expect(json['byte_out'], equals('2000'));
      expect(json['duration'], equals('1h'));
      expect(json['last_packet_receive'], equals('10m'));
    });
  });
}