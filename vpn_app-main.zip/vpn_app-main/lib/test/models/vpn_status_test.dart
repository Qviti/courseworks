import 'package:flutter_test/flutter_test.dart';
import 'package:vpn_basic_project/models/vpn_status.dart';

void main() {
  test('Should correctly parse JSON data to check connectivity', () {
    final testData = {
      'connected': true,
    };

    final vpnStatus = VpnStatus.fromJson(testData);

    expect(vpnStatus.connected, isNotNull);
    expect(vpnStatus.connected, equals(true));
  });
}