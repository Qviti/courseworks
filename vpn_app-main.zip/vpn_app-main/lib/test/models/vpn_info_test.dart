import 'package:flutter_test/flutter_test.dart';
import 'package:vpn_basic_project/models/vpn_info.dart';

void main() {
  group('VpnInfo', () {
    test('should correctly initialize from values', () {
      final vpnInfo = VpnInfo(
        hostname: 'vpn.test.com',
        ip: '192.168.1.1',
        ping: '20ms',
        countryLongName: 'Testland',
        speed: 1000,
        countryShortName: 'TL',
        vpnSessionsNum: 50,
        base64OpenVPNConfigurationData: 'base64StringHere',

      );

      expect(vpnInfo.hostname, 'vpn.test.com');
      expect(vpnInfo.ip, '192.168.1.1');
      expect(vpnInfo.ping, '20ms');
      expect(vpnInfo.speed, 1000);
      expect(vpnInfo.countryLongName, 'Testland');
      expect(vpnInfo.countryShortName, 'TL');
      expect(vpnInfo.vpnSessionsNum, 50);
      expect(vpnInfo.base64OpenVPNConfigurationData, 'base64StringHere');
    });
  });
}