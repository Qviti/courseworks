import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:vpn_basic_project/main.dart' as app;
import 'dart:ui';
void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('VPN Connection Tests', () {
    testWidgets('Connect and Disconnect VPN', (WidgetTester tester) async {
      // Start the app
      app.main();
      await tester.pumpAndSettle();

      final connectButtonFinder = find.byKey(const Key('connectVpnButton'));

      // Tap the connect button
      await tester.tap(connectButtonFinder);
      await tester.pumpAndSettle();

      // Verify the app shows "Connected" status
      expect(find.text('Connected'), findsOneWidget);

      await tester.tap(connectButtonFinder);
      await tester.pumpAndSettle();

      // Verify the app shows "Disconnected" status
      expect(find.text('Disconnected'), findsOneWidget);
    });
  });
}
