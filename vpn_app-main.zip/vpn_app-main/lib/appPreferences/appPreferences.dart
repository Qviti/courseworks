import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:vpn_basic_project/models/vpn_info.dart';
class AppPreferences {
  // Declare a static variable to hold the Hive box instance for storing data.
  static late Box boxOfData;

  // Initialize Hive and open a box to store data.
  static Future<void> initHive() async {
    await Hive.initFlutter(); // Initialize Hive for Flutter.

    boxOfData = await Hive.openBox("data"); // Open a box named "data" to store preferences.
  }
  // Getter and setter for the dark mode preference.
  static bool get isModeDark => boxOfData.get("isModeDark") ?? false;
  static set isModeDark(bool value) => boxOfData.put("isModeDark", value);

  // Getter and setter for the VPN information object.
  static VpnInfo get vpnInfoObj => VpnInfo.fromJson(jsonDecode(boxOfData.get("vpn") ?? '{}'));
  static set vpnInfoObj(VpnInfo value) => boxOfData.put("vpn", jsonEncode(value.toJson()));

  // Getter and setter for the list of VPN servers.
  static List<VpnInfo> get vpnList {
    List<VpnInfo> tempVpnList = [];
    final dataVpn = jsonDecode(boxOfData.get("vpnList") ?? '[]');

    for (var data in dataVpn) {
      tempVpnList.add(VpnInfo.fromJson(data));
    }
    return tempVpnList;
  }
  static set vpnList(List<VpnInfo> valueList) => boxOfData.put("vpnList", jsonEncode(valueList.map((vpn) => vpn.toJson()).toList()));
  static void toggleThemeMode() {
    isModeDark = !isModeDark;
  }
}
