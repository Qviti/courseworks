// Importing necessary Flutter, GetX, and project-specific packages
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vpn_basic_project/controllers/controller_home.dart';
import 'package:vpn_basic_project/models/vpn_status.dart';
import 'package:vpn_basic_project/allScreens/vpn_server_list.dart';
import 'package:vpn_basic_project/allScreens/ip_info_screen.dart';
import 'package:vpn_basic_project/widgets/custom_round_widget.dart';
import 'package:vpn_basic_project/appPreferences/appPreferences.dart';
import 'package:vpn_basic_project/main.dart';
import 'package:vpn_basic_project/vpnEngine/vpn_engine.dart';

import '../widgets/timer_widget.dart';
import 'options_screen.dart';

// HomeScreen class definition, extending StatelessWidget for a stateless widget
class HomeScreen extends StatelessWidget {
  // Constructor with key initialization
  HomeScreen({super.key});

  // Instantiating ControllerHome using GetX for state management
  final homeController = Get.put(ControllerHome());

  // Method to display bottom navigation for location selection
  locationSelectionBottomNavigation(BuildContext context) {
    return SafeArea(
      child: Semantics(
        button: true,
        child: InkWell(
          onTap: () {
            // Navigates to AvailableVpnServersLocationScreen on tap
            Get.to(() => AvailableVpnServersLocationScreen());
          },
          child: Container(
            color: Theme.of(context).bottomNavigationBarTheme.backgroundColor, // Uses theme color for background
            padding: EdgeInsets.symmetric(horizontal: sizeScreen.width * .041),
            height: 62,
            child: Row(
              children: [
                Icon(
                  CupertinoIcons.flag_circle,
                  color: Theme.of(context).bottomNavigationBarTheme.selectedItemColor, // Uses theme color for icon
                  size: 36,
                ),
                const SizedBox(width: 12),
                Text(
                  "Select Server",
                  style: TextStyle(
                    color: Theme.of(context).textTheme.bodyLarge?.color, // Uses theme color for text
                    fontSize: 18,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                Spacer(),
                CircleAvatar(
                  backgroundColor: Theme.of(context).bottomNavigationBarTheme.selectedItemColor, // Uses theme color
                  child: Icon(
                    Icons.keyboard_arrow_right,
                    color: Theme.of(context).primaryColor, // Uses primary color for icon
                    size: 26,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }


  // Widget for the VPN round button
  Widget vpnRoundButton() {
    return Column(
      children: [


        Semantics(
          button: true,
          child: InkWell(
            onTap: () {
              key: const Key('connectVpnButton'); // Assigning a key for testing
              // Calls method to connect/disconnect VPN on tap
              homeController.connectToVpnNow();
            },
            borderRadius: BorderRadius.circular(200),
            child: Container(
              padding: EdgeInsets.all(36),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: homeController.getRoundVpnButtonColor, // Dynamically changes color based on connection state
              ),
              child: Icon(
                Icons.power_settings_new,
                size: 100,
                color: Colors.white,
              ),
            ),
          ),
        ),

        // Timer
        //timer
        Obx(() => TimerWidget(
          initTimerNow: homeController.vpnConnectionState.value == VpnEngine.vpnConnectedNow,
        )),

        SizedBox(height: 20), // Adds spacing between button and status text
        Obx(() => Text(
          homeController.getRoundVpnButtonText, // Dynamically changes text based on connection state
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: homeController.getRoundVpnButtonColor, // Uses dynamic color logic as the button
          ),
        )),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    // Listening to VPN stage changes and updating connection state accordingly
    VpnEngine.snapshotVpnStage().listen((event) {
      homeController.vpnConnectionState.value = event;
    });

    // Getting screen size for layout calculations
    sizeScreen = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor, // Uses theme color for background
        title: Text("LUPIN VPN"),
        leading: IconButton(
          onPressed: ()
          {
            Get.to(()=> ConnectedNetworkIPInfoScreen());
          },
          icon: Icon(Icons.info_outline),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Get.to(() => OptionsScreen()); // Navigate to OptionsScreen
            },
            icon: Icon(Icons.settings),
          ),
        ],
      ),
      bottomNavigationBar: locationSelectionBottomNavigation(context), // Displays the bottom navigation bar
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Displays two custom widgets for location and ping
          Obx(() => Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomWidget(
                titleText: homeController.vpnInfo.value.countryLongName.isEmpty
                    ? "Location"
                    : homeController.vpnInfo.value.countryLongName,
                subTitleText: "FREE",
                roundWidgetWithIcon: CircleAvatar(
                  radius: 32,
                  backgroundColor: Colors.redAccent,
                  child: homeController.vpnInfo.value.countryLongName.isEmpty
                      ? Icon(
                    Icons.flag_circle,
                    size: 30,
                    color: Colors.white,
                  )
                      : null,
                  backgroundImage: homeController.vpnInfo.value.countryLongName.isEmpty
                      ? null
                      : AssetImage("countryFlags/${homeController.vpnInfo.value.countryShortName.toLowerCase()}.png"),
                ),
              ),
              CustomWidget(
                titleText: homeController.vpnInfo.value.countryLongName.isEmpty ? "60 ms" : homeController.vpnInfo.value.ping + " ms",
                subTitleText: "PING",
                roundWidgetWithIcon: CircleAvatar(
                  radius: 32,
                  backgroundColor: Colors.black54,
                  child: Icon(
                    Icons.graphic_eq,
                    size: 30,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          )),
          // Displays the VPN round button
          Obx(() => vpnRoundButton()),
          // Displays two custom widgets for download and upload speeds
          StreamBuilder<VpnStatus?>(
            initialData: VpnStatus(),
            stream: VpnEngine.snapshotVpnStatus(),
            builder: (context, dataSnapshot) {
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomWidget(
                    titleText: "${dataSnapshot.data?.byteIn ?? '0 kbps'}",
                    subTitleText: "DOWNLOAD",
                    roundWidgetWithIcon: CircleAvatar(
                      radius: 32,
                      backgroundColor: Colors.green,
                      child: Icon(
                        Icons.keyboard_arrow_down,
                        size: 30,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  CustomWidget(
                    titleText: "${dataSnapshot.data?.byteOut ?? '0 kbps'}",
                    subTitleText: "UPLOAD",
                    roundWidgetWithIcon: CircleAvatar(
                      radius: 32,
                      backgroundColor: Colors.red, // Uses red color for upload
                      child: Icon(
                        Icons.keyboard_arrow_up,
                        size: 30,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}


