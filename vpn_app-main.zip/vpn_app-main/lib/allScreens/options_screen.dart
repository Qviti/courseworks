import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../main.dart';

class OptionsScreen extends StatefulWidget {
  @override
  _OptionsScreenState createState() => _OptionsScreenState();
}

class _OptionsScreenState extends State<OptionsScreen> {
  bool _isKillSwitchOn = false;
  bool _isAutoStartOn = false;
  //bool AppPreferences.isModeDark = false;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isKillSwitchOn = prefs.getBool('killSwitch') ?? false;
      _isAutoStartOn = prefs.getBool('autoStart') ?? false;
    });
  }

  Future<void> _updatePreference(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Options'),
      ),
      body: ListView(
        children: [
          SwitchListTile(
            title: Text('Killswitch'),
            subtitle: Text('Disable internet when VPN disconnects'),
            value: _isKillSwitchOn,
            onChanged: (value) {
              setState(() => _isKillSwitchOn = value);
              _updatePreference('killSwitch', value);
            },
          ),
          SwitchListTile(
          title: Text('Automatic Start'),
          subtitle: Text('Start VPN automatically on app launch'),
          value: _isAutoStartOn,
          onChanged: (value) {
              setState(() => _isAutoStartOn = value);
              _updatePreference('autoStart', value);
            },
          ),
          SwitchListTile(
          title: Text('Dark mode'),
          value: Get.find<ThemeController>().isDarkMode.value,
          onChanged: (value) {
          Get.find<ThemeController>().toggleThemeMode();
          },
          ),
        ],
      ),
    );
  }
}
