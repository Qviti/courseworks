import 'package:flutter/cupertino.dart';

// To hold network related information
class NetworkIPInfo
{
  String titleText;
  String subtitleText;
  Icon iconData;

  NetworkIPInfo({
    required this.titleText,
    required this.subtitleText,
    required this.iconData,
  });
}