// To hold the IP information
class IPInfo
// Declare and initialize the properties of the IPInfo class
{
  late final String countryName;
  late final String regionName;
  late final String cityName;
  late final String zipCode;
  late final String timezone;
  late final String internetServiceProvider;
  late final String query;

// Constructor for IPInfo
  IPInfo({
    required this.countryName,
    required this.regionName,
    required this.cityName,
    required this.zipCode,
    required this.timezone,
    required this.internetServiceProvider,
    required this.query,
  });

  // For converting a JSON data to a IPInfo instance
  IPInfo.fromJson(Map<String, dynamic> jsonData) {
    // Specifies default value when no data is available
    countryName = jsonData['country'] ?? '';
    regionName = jsonData['regionName'] ?? '';
    cityName = jsonData['city'] ?? '';
    zipCode = jsonData['zip'] ?? '';
    timezone = jsonData['timezone'] ?? 'Unknown';
    internetServiceProvider = jsonData['isp'] ?? 'Unknown';
    query = jsonData['query'] ?? 'Not available';
  }
}