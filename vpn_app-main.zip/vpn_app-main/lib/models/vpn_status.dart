class VpnStatus
{
  // Declare the class properties as optional by setting it as null by default
  String? byteIn;
  String? byteOut;
  String? durationTime;
  String? lastPacketReceive;

  // Define constructor with optional named parameters
  VpnStatus({
    this.byteIn,
    this.byteOut,
    this.durationTime,
    this.lastPacketReceive,
  });

  // Factory constructor to create a VpnStatus object from a Map
  factory VpnStatus.fromJson(Map<String, dynamic> jsonData) {
    return VpnStatus(
      byteIn: jsonData['byte_in'] as String?,
      byteOut: jsonData['byte_out'] as String?,
      durationTime: jsonData['duration'] as String?,
      lastPacketReceive: jsonData['last_packet_receive'] as String?,
    );
  }

  // Method to convert the VpnStatus object to a Map
  Map<String, dynamic> toJson() {
    return {
      'byte_in': byteIn,
      'byte_out': byteOut,
      'duration': durationTime,
      'last_packet_receive': lastPacketReceive,
    };
  }
}